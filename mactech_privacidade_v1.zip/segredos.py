"""Cifra os tokens guardados na base de dados (token do WhatsApp, segredo das integrações).

Define ENCRYPTION_KEY (qualquer texto longo e secreto). Sem ela, os valores ficam em texto simples
(como na versão 1) e o servidor avisa no log de forma bem visível. Se mudares a chave, os tokens antigos deixam de abrir.

Para gerar uma chave forte: python -c "import secrets; print(secrets.token_urlsafe(48))"
"""
import base64
import hashlib
import logging
import os

log = logging.getLogger("mactech.segredos")
_PREFIXO = "enc:"
_fernet = None
_avisou = False


def _f():
    global _fernet
    chave = os.getenv("ENCRYPTION_KEY", "").strip()
    if not chave:
        return None
    if _fernet is None:
        from cryptography.fernet import Fernet
        _fernet = Fernet(base64.urlsafe_b64encode(hashlib.sha256(chave.encode()).digest()))
    return _fernet


def cifrar(valor):
    global _avisou
    if not valor:
        return valor
    f = _f()
    if f is None:
        if not _avisou:
            log.warning(
                "============================================================\n"
                "  ATENÇÃO: ENCRYPTION_KEY não está definida.\n"
                "  Tokens do WhatsApp e segredos de integração ficam em texto simples.\n"
                "  Define ENCRYPTION_KEY no Render (Environment) antes de produção.\n"
                "  Gera com: python -c \"import secrets; print(secrets.token_urlsafe(48))\"\n"
                "============================================================"
            )
            _avisou = True
        return valor
    return _PREFIXO + f.encrypt(valor.encode()).decode()


def decifrar(valor):
    if not valor or not valor.startswith(_PREFIXO):
        return valor or ""   # valor antigo, sem cifra
    f = _f()
    if f is None:
        log.error("Há tokens cifrados mas falta ENCRYPTION_KEY — não é possível ler os tokens")
        return ""
    try:
        return f.decrypt(valor[len(_PREFIXO):].encode()).decode()
    except Exception:
        log.error("Não foi possível decifrar um token (ENCRYPTION_KEY mudou?)")
        return ""


def nova_chave_acesso():
    """Chave de acesso de uma empresa ao seu portal. Devolve (chave, hash): só o hash fica na base de dados."""
    import secrets
    chave = secrets.token_urlsafe(24)
    return chave, hashlib.sha256(chave.encode()).hexdigest()

// Substitui o conteúdo de ASSETS["minha.js"] em assets.py por este bloco (mantém as aspas r''' ... ''')
(function () {
  var K = sessionStorage.getItem('mt_empresa') || '', preenchido = false;
  function $(i) { return document.getElementById(i); }
  function h(t, c, x) { var e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
  function api(m, u, b) {
    return fetch(u, { method: m, headers: { 'X-Empresa-Key': K, 'Content-Type': 'application/json' }, body: b ? JSON.stringify(b) : undefined })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) {
        if (r.status === 401) { sair(); throw new Error('Chave errada'); }
        if (!r.ok) throw new Error(j.erro || ('Erro ' + r.status));
        return j; }); });
  }
  function mostrar(on) { $('entrar').hidden = on; $('portal').hidden = !on; $('sair').hidden = !on; }
  function sair() { sessionStorage.removeItem('mt_empresa'); K = ''; preenchido = false; mostrar(false); }
  var ROT = { pendente: 'À espera da confirmação do pagamento', teste: 'Em teste', ativo: 'Ativa', suspenso: 'Suspensa' };
  function carregar() {
    return api('GET', '/api/minha/resumo').then(function (r) {
      mostrar(true);
      $('nm').textContent = r.nome;
      var st = $('st'); st.textContent = ''; st.appendChild(h('span', 'badge' + (r.ativa ? '' : ' off'), ROT[r.estado] || r.estado));
      $('vd').textContent = r.valido_ate ? 'Válida até ' + new Date(r.valido_ate).toLocaleDateString('pt-PT') : '';
      var lk = $('lk'); lk.textContent = '';
      if (r.chat_url) { var u = location.origin + r.chat_url, a = h('a', null, u); a.href = u; a.target = '_blank'; a.rel = 'noopener'; lk.appendChild(document.createTextNode('Link do seu chat: ')); lk.appendChild(a); }
      $('sm').textContent = 'Últimos 7 dias: ' + r.semana.pessoas + ' pessoas · ' + r.semana.mensagens + ' mensagens · ' + r.semana.respostas_ia + ' respostas da IA · ' + r.semana.sem_resposta + ' sem resposta';
      if (!preenchido) { preenchido = true; $('enm').value = r.nome; $('epr').value = r.system_prompt; $('ehu').checked = r.humano_ativo; }
      var C = $('cv'); C.textContent = '';
      if (!r.conversas.length) C.appendChild(h('p', 'msg', 'Ainda sem conversas.'));
      r.conversas.forEach(function (c) {
        var d = h('div', 'item');
        d.appendChild(h('b', null, c.canal + (c.contacto ? ' · ' + c.contacto : '') + (c.humano ? ' · à espera de pessoa' : '')));
        d.appendChild(h('p', 'msg', c.ultima || ''));
        var row = h('div', 'row');
        var bVer = h('button', 'btn alt', 'Ver conversa'); bVer.type = 'button';
        bVer.onclick = function () {
          api('GET', '/api/minha/conversa/' + c.id).then(function (j) {
            var T = $('tr'); T.textContent = '';
            j.mensagens.forEach(function (m) {
              T.appendChild(h('p', 'msg', (m.remetente === 'user' ? 'Cliente: ' : m.remetente === 'human' ? 'Equipa: ' : 'IA: ') + m.conteudo));
            });
            T.scrollIntoView();
          }).catch(function (x) { alert(x.message); });
        };
        var bAp = h('button', 'btn alt', 'Apagar dados'); bAp.type = 'button';
        bAp.onclick = function () {
          if (!confirm('Apagar todas as mensagens e o contacto deste cliente?\nEsta ação não pode ser desfeita.')) return;
          api('POST', '/api/minha/apagar-cliente', { conversa_id: c.id })
            .then(function () { carregar(); })
            .catch(function (x) { alert(x.message); });
        };
        row.appendChild(bVer); row.appendChild(bAp); d.appendChild(row);
        C.appendChild(d);
      });
      var S = $('sr'); S.textContent = '';
      if (!r.sem_resposta.length) S.appendChild(h('p', 'msg', 'Nada por agora. Bom sinal.'));
      r.sem_resposta.forEach(function (p) { S.appendChild(h('div', 'item', p.pergunta)); });
    });
  }
  $('gv').onclick = function () {
    api('PUT', '/api/minha/info', { nome: $('enm').value, system_prompt: $('epr').value, humano_ativo: $('ehu').checked })
      .then(function () { $('mg').textContent = 'Guardado. O assistente já usa a informação nova.'; preenchido = false; return carregar(); })
      .catch(function (x) { $('mg').textContent = x.message; });
  };
  $('fl').onsubmit = function (ev) {
    ev.preventDefault(); K = $('k').value.trim();
    carregar().then(function () { sessionStorage.setItem('mt_empresa', K); $('k').value = ''; $('ml').textContent = ''; })
      .catch(function (x) { $('ml').textContent = x.message; });
  };
  $('sair').onclick = sair;
  if (K) carregar().catch(function () {}); else mostrar(false);
  setInterval(function () { if (K && !$('portal').hidden) carregar().catch(function () {}); }, 30000);
})();

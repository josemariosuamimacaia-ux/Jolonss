"""Páginas públicas da MacTech: início com 3 botões, lista de empresas para clientes e registo de empresas.

Só o Dono (botão "Dono" -> /painel) usa a chave de administração. Clientes e empresas nunca a veem.
Empresas que se registam sozinhas ficam 'pendentes' (invisíveis aos clientes) até o dono confirmar o
pagamento e carregar em "Ativar (pagou)" no painel."""
import logging
import os

from flask import jsonify, render_template_string, request
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Mapped, mapped_column

from models import Base, Empresa, SessionLocal, agora, engine
from segredos import nova_chave_acesso

log = logging.getLogger("mactech.publico")


class PedidoEmpresa(Base):
    """Dados de contacto e de pagamento de uma empresa que se registou sozinha (só o dono os vê)."""
    __tablename__ = "pedidos_empresa"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    empresa_id: Mapped[int] = mapped_column(ForeignKey("empresas.id"), index=True)
    contacto: Mapped[str] = mapped_column(String(120))
    ref_pagamento: Mapped[str] = mapped_column(String(120))
    aceitou_termos_em: Mapped[object] = mapped_column(DateTime(timezone=True), default=agora)


Base.metadata.create_all(engine)   # cria só a tabela nova, se ainda não existir

TERMOS = """MODELO DE TERMOS (o dono deve rever e adaptar com um advogado antes de usar com clientes reais)

1. Serviço: a MacTech fornece um assistente de atendimento com inteligência artificial, que responde a clientes da empresa por chat e/ou WhatsApp com base nas informações que a empresa fornece.
2. Informação da empresa: a empresa é responsável pela exactidão e actualização das informações (produtos, preços, horários). O assistente usa apenas essas informações, mas pode cometer erros; a empresa deve acompanhar as conversas.
3. Pagamento: o serviço é activado depois de a MacTech confirmar o pagamento inicial. Sem pagamento confirmado, a empresa não aparece aos clientes.
4. Teste: as empresas abordadas pela MacTech podem ter um período de teste gratuito de 1 dia.
5. Dados: as conversas entre clientes e o assistente são guardadas para prestar o serviço e melhorar o atendimento. A empresa deve informar os seus clientes disso.
6. Suspensão: a MacTech pode suspender o serviço por falta de pagamento, uso abusivo ou conteúdo ilegal.
7. Limites: o serviço pode ficar indisponível por falhas técnicas ou dos fornecedores de IA, sem que isso dê direito a indemnização."""

# ---------- páginas ----------
BASE_CSS = """<style>
:root{color-scheme:light dark;--verde:#128c4a;--verde-escuro:#08743a;--fundo:#f3f7f4;--texto:#13251e;--suave:#52665b;--borda:#d5e2d9;--cartao:#fff;--foco:#8bd7a8}
*{box-sizing:border-box}html{min-height:100%;scroll-behavior:smooth}body{margin:0;min-height:100vh;background:radial-gradient(ellipse at top right,#e1f3e7 0,transparent 42%),var(--fundo);color:var(--texto);font:16px/1.6 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;padding:clamp(14px,4vw,32px)}
main{width:100%;max-width:680px;margin:clamp(12px,5vh,48px) auto}h1{font-size:clamp(30px,7vw,44px);line-height:1.12;letter-spacing:-.04em;margin:12px 0 8px}h1 span{color:var(--verde)}p{color:var(--suave);margin:10px 0 18px}a{color:var(--verde-escuro);text-underline-offset:3px}a:focus-visible,button:focus-visible,input:focus-visible,textarea:focus-visible,summary:focus-visible{outline:3px solid var(--foco);outline-offset:3px}
.card{display:block;background:var(--cartao);border:1px solid var(--borda);border-radius:18px;padding:clamp(15px,3.5vw,22px);margin:14px 0;box-shadow:0 8px 24px rgba(20,65,42,.055)}
.btn{display:flex;align-items:center;justify-content:center;min-height:50px;width:100%;margin:12px 0;background:var(--verde);color:#fff;border:1px solid var(--verde);border-radius:14px;padding:13px 18px;font:650 16px/1.3 system-ui,sans-serif;text-align:center;text-decoration:none;cursor:pointer;transition:background .15s ease,transform .15s ease,border-color .15s ease}.btn:hover{background:var(--verde-escuro);border-color:var(--verde-escuro)}.btn:active{transform:translateY(1px)}.btn.alt{background:var(--cartao);color:var(--verde-escuro);border-color:var(--borda)}.btn.alt:hover{background:#e9f7ee;border-color:#a7d8b8}.btn:disabled{opacity:.65;cursor:wait}
label{display:block;margin:15px 0 6px;font-weight:650;font-size:14px}input,textarea{display:block;width:100%;min-height:46px;background:var(--cartao);color:var(--texto);border:1px solid #bdcec2;border-radius:11px;padding:11px 12px;font:16px/1.45 system-ui,sans-serif}textarea{min-height:80px;resize:vertical}input::placeholder,textarea::placeholder{color:#718277}input[type=checkbox]{display:inline-block;width:18px;min-height:18px;height:18px;vertical-align:middle;margin:0 8px 0 0;accent-color:var(--verde)}
.msg{min-height:1.4em;overflow-wrap:anywhere}.erro{color:#b3261e}.ok{color:var(--verde-escuro);font-weight:650}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.55 system-ui,sans-serif;margin:8px 0 0}.item{display:block;text-decoration:none;color:inherit;transition:border-color .15s ease,transform .15s ease}.item:hover{border-color:#8fcba4;transform:translateY(-1px)}.item b{font-size:18px}.h{position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden}
summary{cursor:pointer;font-weight:600;padding:6px 0}button, input, textarea{font-family:inherit}.nota{font-size:13px}.marca{display:inline-flex;align-items:center;gap:8px;font-weight:750;letter-spacing:-.03em}.marca:before{content:"M";display:grid;place-items:center;width:34px;height:34px;border-radius:11px;background:var(--verde);color:white;font-size:19px}
@media(prefers-color-scheme:dark){:root{--fundo:#0b1511;--texto:#e7f2eb;--suave:#b1c5b8;--borda:#294638;--cartao:#13221a;--verde:#35b96d;--verde-escuro:#70d99a;--foco:#8bd7a8}body{background:radial-gradient(ellipse at top right,#183b28 0,transparent 42%),var(--fundo)}.btn.alt{color:var(--verde-escuro)}.btn.alt:hover{background:#1b3525}input,textarea{border-color:#365644}input::placeholder,textarea::placeholder{color:#9ab0a0}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{scroll-behavior:auto!important;transition:none!important}}
</style>"""

INICIO = """<!DOCTYPE html><html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>MacTech</title>""" + BASE_CSS + """</head><body><main>
<div class="marca">MacTech</div><h1>Atendimento inteligente para empresas.</h1>
<p>Assistentes de atendimento com IA para empresas.</p>
<a class="btn" href="/clientes">Sou cliente: quero fazer perguntas</a>
<a class="btn alt" href="/empresas">Sou uma empresa: quero registar-me</a>
<a class="btn alt" href="/minha-empresa">Já sou empresa: entrar</a>
<a class="btn alt" href="/painel">Dono</a>
</main></body></html>"""

CLIENTES = """<!DOCTYPE html><html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>MacTech · Empresas</title>""" + BASE_CSS + """</head><body><main>
<p><a href="/">&larr; Início</a></p>
<h1>Escolha a empresa</h1>
<p>Toque na empresa com quem quer falar.</p>
<input id="q" placeholder="Procurar empresa" aria-label="Procurar empresa">
<div id="lista"></div><p id="vazio" class="msg"></p>
<script>
var todas = [];
function mostrar() {
  var q = document.getElementById('q').value.toLowerCase(), L = document.getElementById('lista');
  L.textContent = '';
  var f = todas.filter(function (e) { return e.nome.toLowerCase().indexOf(q) >= 0; });
  f.forEach(function (e) {
    var a = document.createElement('a'); a.className = 'card item'; a.href = '/c/' + encodeURIComponent(e.slug);
    var b = document.createElement('b'); b.textContent = e.nome; a.appendChild(b); L.appendChild(a);
  });
  document.getElementById('vazio').textContent = f.length ? '' : (todas.length ? 'Nenhuma empresa encontrada.' : 'Ainda não há empresas disponíveis.');
}
fetch('/api/publico/empresas').then(function (r) { return r.json(); }).then(function (j) { todas = j.empresas || []; mostrar(); })
  .catch(function () { document.getElementById('vazio').textContent = 'Não foi possível carregar a lista. Tente de novo.'; });
document.getElementById('q').oninput = mostrar;
</script></main></body></html>"""

EMPRESAS = """<!DOCTYPE html><html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>MacTech · Registar empresa</title>""" + BASE_CSS + """</head><body><main>
<p><a href="/">&larr; Início</a></p>
<h1>Registar empresa</h1>
<div class="card"><b>1. Termos</b><details><summary>Ler os termos</summary><pre>{{ termos }}</pre></details></div>
<div class="card"><b>2. Pagamento inicial</b><pre>{{ pagamento }}</pre></div>
<form id="f" class="card"><b>3. Dados da empresa</b>
<label for="n">Nome da empresa</label><input id="n" maxlength="120" required>
<label for="s">Sector (ex.: loja de tecnologia, clínica)</label><input id="s" maxlength="120">
<label for="d">O que a empresa faz</label><textarea id="d" rows="2" maxlength="1000"></textarea>
<label for="p">Produtos ou serviços (um por linha, com preços e detalhes)</label><textarea id="p" rows="5" maxlength="8000" required></textarea>
<label for="h">Horário</label><input id="h" maxlength="200">
<label for="l">Contactos e localização</label><input id="l" maxlength="300">
<label for="g">Garantia, entrega e pagamento</label><textarea id="g" rows="2" maxlength="1000"></textarea>
<label for="c">O seu telefone ou email (só a MacTech vê)</label><input id="c" maxlength="120" required>
<label for="r">Referência ou comprovativo do pagamento (número da transferência)</label><input id="r" maxlength="120" required>
<input class="h" id="w" tabindex="-1" autocomplete="off" aria-hidden="true">
<label><input type="checkbox" id="t" required> Li e aceito os termos</label>
<button class="btn" type="submit">Enviar pedido</button>
<p id="m" class="msg"></p></form>
<script>
function v(i) { return document.getElementById(i).value.trim(); }
document.getElementById('f').onsubmit = function (ev) {
  ev.preventDefault();
  var f = document.getElementById('f'), botao = f.querySelector('button[type="submit"]');
  var m = document.getElementById('m');
  if (!f.reportValidity()) return;
  m.className = 'msg'; m.textContent = 'A enviar o pedido…'; botao.disabled = true; botao.textContent = 'A enviar…';
  fetch('/api/publico/registar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
    nome: v('n'), sector: v('s'), descricao: v('d'), produtos: v('p'), horario: v('h'), local: v('l'), politicas: v('g'),
    contacto: v('c'), ref_pagamento: v('r'), aceita_termos: document.getElementById('t').checked, website: v('w') }) })
    .then(function (r) { return r.text().then(function (texto) { var j; try { j = JSON.parse(texto); } catch (_) { j = {}; } return { ok: r.ok, j: j }; }); })
    .then(function (x) {
      if (x.ok && x.j.ok !== false) {
        m.className = 'msg ok';
        m.textContent = 'Pedido enviado. GUARDE esta chave (não volta a ser mostrada): ' + (x.j.chave || 'não recebida; contacte a MacTech') + '. Serve para entrar em Minha empresa. A empresa só fica disponível aos clientes depois da confirmação do pagamento.';
        f.reset();
      } else { m.className = 'msg erro'; m.textContent = x.j.erro || 'Não foi possível enviar. Tente novamente.'; }
    }).catch(function () { m.className = 'msg erro'; m.textContent = 'Não foi possível contactar o servidor. Verifique a ligação e tente de novo.'; })
    .finally(function () { botao.disabled = false; botao.textContent = 'Enviar pedido'; });
};
</script></main></body></html>"""


def _prompt(d, f):
    """Mesmo formato do formulário do painel."""
    linhas = [l.strip() for l in f["produtos"].split("\n") if l.strip()]
    return (f["nome"] + (f" ({f['sector']})" if f["sector"] else "") + ". " + f["descricao"] + "\nProdutos e serviços:\n"
            + "\n".join("- " + l for l in linhas)
            + (f"\nHorário: {f['horario']}" if f["horario"] else "")
            + (f"\nContactos e localização: {f['local']}" if f["local"] else "")
            + (f"\nGarantia, entrega e pagamento: {f['politicas']}" if f["politicas"] else ""))


def registar(app, exige_admin, limite_excedido, empresa_ativa, gerar_slug):
    @app.get("/clientes")
    def pagina_clientes():
        return CLIENTES

    @app.get("/empresas")
    def pagina_empresas():
        pagamento = os.environ.get("PAGAMENTO_INSTRUCOES", "").strip() or (
            "Os dados de pagamento serão indicados pela MacTech. Contacte-nos para os receber.")
        return render_template_string(EMPRESAS, termos=TERMOS, pagamento=pagamento)

    @app.get("/api/publico/empresas")
    def listar_publico():
        """Só empresas aprovadas (pagas ou em teste dentro do prazo). Nunca mostra pendentes nem suspensas."""
        with SessionLocal() as db:
            ativas = [e for e in db.query(Empresa).filter(Empresa.slug.isnot(None)).order_by(Empresa.nome).all()
                      if empresa_ativa(e)]
            return jsonify(empresas=[{"nome": e.nome, "slug": e.slug} for e in ativas])

    @app.post("/api/publico/registar")
    def registar_empresa():
        d = request.get_json(silent=True) or {}
        if str(d.get("website") or "").strip():       # campo-armadilha: só os robôs o preenchem
            return jsonify(ok=True), 201
        if limite_excedido(("registo", request.remote_addr), 10, 3600):
            return jsonify(erro="Demasiados pedidos. Tente daqui a uma hora."), 429

        def t(campo, maximo):
            return str(d.get(campo) or "").strip()[:maximo]
        f = {"nome": t("nome", 120), "sector": t("sector", 120), "descricao": t("descricao", 1000),
             "produtos": t("produtos", 8000), "horario": t("horario", 200), "local": t("local", 300),
             "politicas": t("politicas", 1000)}
        contacto, ref = t("contacto", 120), t("ref_pagamento", 120)
        em_falta = [n for n, v in (("nome da empresa", f["nome"]), ("produtos ou serviços", f["produtos"]),
                                   ("telefone ou email", contacto), ("referência do pagamento", ref)) if not v]
        if em_falta:
            return jsonify(erro="Preencha: " + ", ".join(em_falta) + "."), 400
        if d.get("aceita_termos") is not True:
            return jsonify(erro="Tem de aceitar os termos."), 400
        chave, chave_hash = nova_chave_acesso()
        empresa = Empresa(nome=f["nome"], system_prompt=_prompt(d, f), humano_ativo=True, no_hub=True,
                          estado="pendente", teste_ate=None, chave_hash=chave_hash)
        with SessionLocal() as db:
            empresa.slug = gerar_slug(db, f["nome"])
            db.add(empresa)
            try:
                db.flush()
                db.add(PedidoEmpresa(empresa_id=empresa.id, contacto=contacto, ref_pagamento=ref))
                db.commit()
            except IntegrityError:
                db.rollback()
                log.exception("Não foi possível registar a empresa")
                return jsonify(erro="Não foi possível registar. Tente de novo."), 409
        log.warning("[ATENÇÃO] Novo pedido de empresa: %s (confirmar pagamento no painel)", f["nome"])
        return jsonify(ok=True, chave=chave), 201

    @app.get("/api/pedidos")
    @exige_admin
    def listar_pedidos():
        """Contacto e referência de pagamento por empresa (só o dono)."""
        with SessionLocal() as db:
            return jsonify(pedidos={p.empresa_id: {"contacto": p.contacto, "ref_pagamento": p.ref_pagamento}
                                    for p in db.query(PedidoEmpresa).all()})
